# 🚀 LOOM SOLAR - LOCAL MYSQL SETUP GUIDE

## 📋 **PREREQUISITES**

1. **MySQL Server** installed on your system
2. **MySQL Workbench** (for database management)
3. **Node.js** (version 16+ recommended)
4. **npm** or **yarn** package manager

## 🔧 **STEP-BY-STEP SETUP**

### **Step 1: Download & Extract Project**
```bash
# Download the project files to your local machine
# Extract to a folder like: C:\LoomSolar or ~/LoomSolar
```

### **Step 2: Install Dependencies**
```bash
cd LoomSolar
npm install
```

### **Step 3: MySQL Database Setup**

#### **Option A: Using MySQL Workbench (Recommended)**
1. Open MySQL Workbench
2. Connect to your MySQL server
3. Create a new database:
   ```sql
   CREATE DATABASE loom_solar;
   ```
4. The application will automatically create all tables and sample data

#### **Option B: Using Command Line**
```bash
mysql -u root -p
CREATE DATABASE loom_solar;
exit
```

### **Step 4: Configure Database Connection**
Edit `server/clean-server.js` (lines 27-33):
```javascript
const dbConfig = {
  host: 'localhost',           // Your MySQL host
  user: 'root',               // Your MySQL username
  password: 'your_password',   // Your MySQL password
  database: 'loom_solar',     // Database name
  charset: 'utf8mb4'
};
```

### **Step 5: Create Environment File (Optional)**
Create `.env` file in project root:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=loom_solar
JWT_SECRET=your-secret-key-here
PORT=5000
```

### **Step 6: Start the Application**
```bash
node server/clean-server.js
```

You should see:
```
=================================================
🟢 LOOM SOLAR E-COMMERCE SERVER RUNNING
=================================================
Port: 5000
Database: MySQL2 (loom_solar)
```

### **Step 7: Access the Application**
Open your browser and go to: `http://localhost:5000`

## 📊 **SAMPLE LOGIN CREDENTIALS**

### **Admin Account**
- **Email**: admin@loomsolar.com
- **Password**: admin123
- **Access**: Full admin dashboard, product management, order management

### **User Account**
- **Email**: user@loomsolar.com
- **Password**: user123
- **Access**: Shopping, orders, profile management

## 🔍 **VERIFY ALL FUNCTIONALITY**

### **🏠 HOME PAGE** (`http://localhost:5000/`)
- ✅ Hero section with Loom Solar branding
- ✅ Featured products display
- ✅ Blog posts preview
- ✅ Navigation menu works
- ✅ Search functionality

### **🛍️ SHOP PAGE** (`http://localhost:5000/shop`)
- ✅ Product grid display
- ✅ Category filtering (Solar Panels, Storage Battery, PV Inverter)
- ✅ Search by product name
- ✅ Sort by price (low to high, high to low)
- ✅ Product cards with prices and images

### **📱 PRODUCT DETAIL PAGE** (`http://localhost:5000/product/:id`)
- ✅ Product images and description
- ✅ Price display
- ✅ Stock quantity
- ✅ Add to Cart button
- ✅ Buy Now button
- ✅ Quantity selector

### **🛒 SHOPPING CART** (`http://localhost:5000/cart`)
- ✅ Cart items display
- ✅ Update quantity buttons
- ✅ Remove items
- ✅ Total calculation
- ✅ Shipping information form
- ✅ Checkout process

### **👤 USER AUTHENTICATION**
- ✅ Register page (`http://localhost:5000/register`)
- ✅ Login page (`http://localhost:5000/login`)
- ✅ Password validation
- ✅ JWT token generation
- ✅ Protected routes

### **📊 USER DASHBOARD** (`http://localhost:5000/dashboard`)
- ✅ Order history
- ✅ Account information
- ✅ Order status tracking
- ✅ Order details view

### **⚙️ ADMIN DASHBOARD** (`http://localhost:5000/admin`)
- ✅ Dashboard statistics
- ✅ Product management (Add/Edit/Delete)
- ✅ Order management
- ✅ Order status updates
- ✅ Blog post management
- ✅ File upload for images

### **📝 BLOG SYSTEM** (`http://localhost:5000/blog`)
- ✅ Blog post listing
- ✅ Individual blog post pages
- ✅ Admin blog management
- ✅ Create/Edit/Delete posts

### **🔐 API ENDPOINTS** (All working with MySQL2)
- ✅ `/api/auth/register` - User registration
- ✅ `/api/auth/login` - User login
- ✅ `/api/auth/user` - Get current user
- ✅ `/api/products` - Get all products
- ✅ `/api/products/categories/all` - Get categories
- ✅ `/api/products/category/:id` - Get products by category
- ✅ `/api/products/search/:query` - Search products
- ✅ `/api/products/:id` - Get single product
- ✅ `/api/cart` - Get cart items
- ✅ `/api/cart/add` - Add to cart
- ✅ `/api/cart/update` - Update cart
- ✅ `/api/cart/remove/:id` - Remove from cart
- ✅ `/api/orders/create` - Create order
- ✅ `/api/orders/my-orders` - Get user orders
- ✅ `/api/admin/stats` - Admin dashboard stats
- ✅ `/api/admin/products` - Admin product management
- ✅ `/api/admin/orders` - Admin order management
- ✅ `/api/blog` - Blog posts
- ✅ `/api/blog/admin/posts` - Admin blog management

## 🗄️ **DATABASE TABLES** (Auto-created)

The application automatically creates these tables:
- `users` - User accounts and authentication
- `categories` - Product categories
- `products` - Product catalog
- `cart_items` - Shopping cart items
- `orders` - Order records
- `order_items` - Order line items
- `blog_posts` - Blog content

## 🎨 **FEATURES INCLUDED**

### **User Features**
- Product browsing and search
- Shopping cart management
- Order placement and tracking
- User account management
- Blog reading

### **Admin Features**
- Dashboard with statistics
- Product CRUD operations
- Order management
- Blog management
- File upload for images

### **Technical Features**
- JWT authentication
- Role-based access control
- File upload handling
- Stock management
- Order processing
- MySQL2 with raw SQL queries
- Responsive design

## 🔧 **TROUBLESHOOTING**

### **Database Connection Issues**
- Ensure MySQL server is running
- Check username/password in config
- Verify database exists
- Check firewall settings

### **Port Issues**
- Change PORT in config if 5000 is occupied
- Use `netstat -an | grep 5000` to check port usage

### **Permission Issues**
- Ensure MySQL user has proper permissions
- Grant privileges if needed:
  ```sql
  GRANT ALL PRIVILEGES ON loom_solar.* TO 'username'@'localhost';
  ```

## 📁 **PROJECT STRUCTURE**
```
loom_solar/
├── server/
│   └── clean-server.js      # Main server file (MySQL2)
├── src/
│   ├── components/          # React components
│   ├── pages/              # All pages
│   ├── hooks/              # Custom hooks
│   └── utils/              # Utilities
├── public/
├── uploads/                # File uploads
├── package.json
└── README.md
```

## ✅ **VERIFICATION CHECKLIST**

After setup, verify these work:
- [ ] Home page loads with products
- [ ] Shop page shows all products
- [ ] Product details page works
- [ ] User can register/login
- [ ] Shopping cart functions
- [ ] Orders can be placed
- [ ] Admin dashboard accessible
- [ ] Product management works
- [ ] Blog system operational
- [ ] All links navigate properly
- [ ] No broken functionality

## 🎯 **FINAL NOTES**

- **Database**: Pure MySQL2 with raw SQL queries
- **Compatible**: Works with MySQL Workbench
- **Production Ready**: All features tested and working
- **Scalable**: Clean code structure for easy maintenance
- **Secure**: JWT authentication, input validation, SQL injection protection

Your complete Loom Solar e-commerce platform is ready to run on your local MySQL system!