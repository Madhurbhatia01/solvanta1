# Loom Solar - Full Stack Web Application

## Overview

This is a full-stack e-commerce web application for Loom Solar, India's leading solar company. The application provides a complete solar product marketplace with separate admin and user dashboards, product management, shopping cart functionality, and integrated payment processing.

## User Preferences

Preferred communication style: Simple, everyday language.
**CRITICAL**: Must use MySQL2 with raw SQL queries only - NO PostgreSQL, NO ORMs
**CRITICAL**: Must work with MySQL Workbench for database GUI management
**CRITICAL**: User will run on local machine if needed
**CRITICAL**: Every single link and functionality must work perfectly - no broken links or features allowed

## System Architecture

### Frontend Architecture
- **Framework**: React 19.1.0 with JavaScript (no TypeScript)
- **Styling**: TailwindCSS with custom Loom Solar theme (dark green and black)
- **Routing**: React Router DOM for client-side navigation
- **State Management**: React Context API for authentication and cart management
- **HTTP Client**: Axios for API communication

### Backend Architecture
- **Framework**: Node.js with Express.js 5.1.0
- **Database**: MySQL 2 with mysql2 driver (no ORM - raw SQL queries)
- **Authentication**: JWT (JSON Web Tokens) with bcryptjs for password hashing
- **File Upload**: Multer for handling image uploads
- **Security**: CORS enabled, express-rate-limit for API protection

### Key Components

1. **Authentication System**
   - JWT-based authentication
   - Role-based access control (admin/user)
   - Protected routes and middleware

2. **Product Management**
   - CRUD operations for products
   - Category-based organization
   - Image upload and management
   - Stock quantity tracking

3. **Shopping Cart**
   - Add/remove items
   - Quantity management
   - Persistent cart for logged-in users

4. **Order Management**
   - Order creation and tracking
   - Payment integration with Razorpay
   - Order history for users

5. **Admin Dashboard**
   - Product management
   - Order management
   - Blog post management
   - User management
   - Analytics and statistics

6. **User Dashboard**
   - Order history
   - Account management
   - Cart management

7. **Blog System**
   - Blog post creation and management
   - Rich content support
   - SEO-friendly URLs

## Data Flow

1. **User Authentication**: Login/Register → JWT Token → Protected Routes
2. **Product Browsing**: Home/Shop → API → Product Cards → Product Details
3. **Shopping**: Add to Cart → Cart Management → Checkout → Payment → Order
4. **Admin Operations**: Admin Login → Dashboard → CRUD Operations → Database Updates

## External Dependencies

### Payment Integration
- **Razorpay**: For processing payments
- Configured in `server/utils/razorpay.js`
- Environment variables: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`

### File Storage
- **Multer**: For file uploads (images)
- Files stored in `uploads/` directory
- Served statically through Express

### UI Components
- **Font Awesome**: For icons
- **Feather Icons**: Additional icon set
- **TailwindCSS**: Complete styling framework

## Database Schema

The application uses MySQL with the following main tables:
- `users` - User accounts and authentication
- `products` - Product catalog
- `categories` - Product categories
- `cart_items` - Shopping cart items
- `orders` - Order records
- `order_items` - Order line items
- `blog_posts` - Blog content

## Deployment Strategy

### Environment Configuration
- Database connection via environment variables
- JWT secret configuration
- Razorpay API keys
- File upload paths

### Development Setup
1. Install dependencies with `npm install`
2. Configure MySQL database
3. Set up environment variables
4. Start backend server on port 8000
5. Start React development server

### Production Considerations
- Static file serving for uploaded images
- Rate limiting for API endpoints
- CORS configuration for frontend domain
- Database connection pooling
- Error handling and logging

## Security Features

1. **Authentication**: JWT tokens with expiration
2. **Authorization**: Role-based access control
3. **Password Security**: bcryptjs hashing
4. **Rate Limiting**: Express rate limit middleware
5. **Input Validation**: Server-side validation
6. **File Upload Security**: Multer configuration with file type restrictions

## API Structure

The backend provides RESTful APIs organized by domain:
- `/api/auth` - Authentication endpoints
- `/api/products` - Product management
- `/api/cart` - Shopping cart operations
- `/api/orders` - Order management
- `/api/admin` - Admin-only endpoints
- `/api/blog` - Blog management

Each route includes appropriate authentication and authorization middleware where required.