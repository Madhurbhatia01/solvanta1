const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static("uploads"));

// Database configuration
const dbConfig = {
  host: "localhost",
  user: "root",
  password: "1234", // CHANGE THIS TO YOUR MYSQL PASSWORD
  database: "solvantadb2",
  charset: "utf8mb4",
  supportBigNumbers: true,
  bigNumberStrings: true
};

// Create database connection
async function createConnection() {
  return await mysql.createConnection(dbConfig);
}

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || "loom-solar-secret-key";

// File upload configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage: storage });

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Access token required" });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: "Invalid token" });
    }
    req.user = user;
    next();
  });
};

// Admin middleware
const requireAdmin = (req, res, next) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" });
  }
  next();
};

// Initialize database
async function initializeDatabase() {
  try {
    console.log("Initializing database...");

    // First connect without database to create it
    const dbConfigWithoutDb = {
      host: dbConfig.host,
      user: dbConfig.user,
      password: dbConfig.password,
      charset: "utf8mb4",
      supportBigNumbers: true,
      bigNumberStrings: true
    };

    const db = await mysql.createConnection(dbConfigWithoutDb);

    // Create database if it doesn't exist
    await db.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\``);
    await db.end();

    // Now connect to the specific database
    const dbWithDatabase = await mysql.createConnection(dbConfig);
    console.log(`Database "${dbConfig.database}" initialized successfully`);

    // Create tables
    await dbWithDatabase.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        first_name VARCHAR(100),
        last_name VARCHAR(100),
        role VARCHAR(50) DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    await dbWithDatabase.query(`
      CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        slug VARCHAR(100) UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbWithDatabase.query(`
      CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        category_id INT,
        stock_quantity INT DEFAULT 0,
        image_url VARCHAR(500),
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id)
      )
    `);

    await dbWithDatabase.query(`
      CREATE TABLE IF NOT EXISTS cart_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (product_id) REFERENCES products(id),
        UNIQUE KEY unique_user_product (user_id, product_id)
      )
    `);

    await dbWithDatabase.query(`
      CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        shipping_address TEXT,
        payment_method VARCHAR(50),
        payment_id VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    `);

    await dbWithDatabase.query(`
      CREATE TABLE IF NOT EXISTS order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (product_id) REFERENCES products(id)
      )
    `);

    await dbWithDatabase.query(`
      CREATE TABLE IF NOT EXISTS blog_posts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        content TEXT,
        excerpt TEXT,
        slug VARCHAR(255) UNIQUE,
        author_id INT,
        featured_image VARCHAR(500),
        is_published BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (author_id) REFERENCES users(id)
      )
    `);

    // Insert sample data
    const adminHash = await bcrypt.hash("admin123", 10);
    const userHash = await bcrypt.hash("user123", 10);

    await dbWithDatabase.query(
      `INSERT IGNORE INTO users (email, password, first_name, last_name, role) VALUES
      ('admin@loomsolar.com', '${adminHash}', 'Admin', 'User', 'admin'),
      ('user@loomsolar.com', '${userHash}', 'Test', 'User', 'user')`
    );

    await dbWithDatabase.query(`
      INSERT IGNORE INTO categories (id, name, description, slug) VALUES
      (1, 'Solar Panels', 'High-efficiency solar panels for residential and commercial use', 'solar-panels'),
      (2, 'Storage Battery', 'Advanced battery storage systems for solar energy', 'storage-battery'),
      (3, 'PV Inverter', 'Power inverters for converting DC to AC power', 'pv-inverter')
    `);

    await dbWithDatabase.query(`
      INSERT IGNORE INTO products (id, name, description, price, category_id, stock_quantity, image_url) VALUES
      (1, 'Loom Solar 100W Mono Panel', 'High-efficiency monocrystalline solar panel with 100W capacity', 5500.00, 1, 100, 'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=400'),
      (2, 'Loom Solar 200W Mono Panel', 'Premium monocrystalline solar panel with 200W capacity', 9500.00, 1, 80, 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400'),
      (3, 'Loom Solar 300W Mono Panel', 'Advanced monocrystalline solar panel with 300W capacity', 13500.00, 1, 60, 'https://images.unsplash.com/photo-1497440001374-f26997328c1b?w=400'),
      (4, 'Loom Solar 3KW Lithium Battery', 'Advanced lithium battery storage system with 3KW capacity', 85000.00, 2, 50, 'https://images.unsplash.com/photo-1609221542654-8f7b804a2fb3?w=400'),
      (5, 'Loom Solar 5KW Lithium Battery', 'High-capacity lithium battery storage system with 5KW capacity', 125000.00, 2, 30, 'https://images.unsplash.com/photo-1609668645159-3b4f9e5c6e63?w=400'),
      (6, 'Loom Solar 3KW Inverter', 'Efficient PV inverter with 3KW capacity for residential use', 35000.00, 3, 75, 'https://images.unsplash.com/photo-1581091870628-12f9e6a7b889?w=400'),
      (7, 'Loom Solar 5KW Inverter', 'High-performance PV inverter with 5KW capacity for commercial use', 55000.00, 3, 45, 'https://images.unsplash.com/photo-1581092795442-b0c88a7a5b94?w=400')
    `);

    await dbWithDatabase.query(`
      INSERT IGNORE INTO blog_posts (id, title, content, excerpt, slug, author_id, featured_image, is_published) VALUES
      (1, 'Solar Energy: The Future of Power', 'Solar energy is revolutionizing the way we power our homes and businesses. With advances in technology and decreasing costs, solar power has become one of the most viable renewable energy sources available today.', 'Discover how solar energy is changing the world', 'solar-energy-future-power', 1, 'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800', TRUE),
      (2, 'Best Solar Panels for Your Home', 'Choosing the right solar panels for your home is crucial for maximizing energy efficiency and return on investment. This comprehensive guide will help you understand the different types of solar panels and their benefits.', 'Guide to selecting the perfect solar panels', 'best-solar-panels-home', 1, 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800', TRUE),
      (3, 'Solar Battery Storage Solutions', 'Battery storage systems are essential for storing solar energy for later use. Learn about the different types of batteries, their benefits, and how to choose the right storage solution for your needs.', 'Everything you need to know about solar batteries', 'solar-battery-storage-solutions', 1, 'https://images.unsplash.com/photo-1609221542654-8f7b804a2fb3?w=800', TRUE)
    `);

    await dbWithDatabase.end();
    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Database initialization failed:", error);
    throw error;
  }
}

// ============= AUTHENTICATION ROUTES =============

// Register
app.post("/api/auth/register", async (req, res) => {
  const { email, password, firstName, lastName } = req.body;

  try {
    const db = await createConnection();

    // Check if user exists
    const [existingUsers] = await db.execute(
      "SELECT id FROM users WHERE email = ?",
      [email],
    );

    if (existingUsers.length > 0) {
      await db.end();
      return res.status(400).json({ error: "User already exists" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const [result] = await db.execute(
      "INSERT INTO users (email, password, first_name, last_name) VALUES (?, ?, ?, ?)",
      [email, hashedPassword, firstName, lastName],
    );

    const userId = result.insertId;

    // Generate token
    const token = jwt.sign({ id: userId, email, role: "user" }, JWT_SECRET, {
      expiresIn: "24h",
    });

    await db.end();

    res.status(201).json({
      token,
      user: {
        id: userId,
        email,
        firstName,
        lastName,
        role: "user",
      },
    });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({ error: "Registration failed" });
  }
});

// Login
app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const db = await createConnection();

    // Find user
    const [users] = await db.execute("SELECT * FROM users WHERE email = ?", [
      email,
    ]);

    if (users.length === 0) {
      await db.end();
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const user = users[0];

    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      await db.end();
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // Generate token
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: "24h" },
    );

    await db.end();

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
      },
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Login failed" });
  }
});

// Get current user
app.get("/api/auth/user", authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();

    const [users] = await db.execute("SELECT * FROM users WHERE id = ?", [
      req.user.id,
    ]);

    if (users.length === 0) {
      await db.end();
      return res.status(404).json({ error: "User not found" });
    }

    const user = users[0];

    await db.end();

    res.json({
      id: user.id,
      email: user.email,
      firstName: user.first_name,
      lastName: user.last_name,
      role: user.role,
    });
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ error: "Failed to fetch user" });
  }
});

// ============= PRODUCT ROUTES =============

// Get all products
app.get("/api/products", async (req, res) => {
  try {
    const db = await createConnection();
    const [products] = await db.execute(`
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE p.is_active = 1
      ORDER BY p.created_at DESC
    `);
    await db.end();
    res.json(products);
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ error: "Failed to fetch products" });
  }
});

// Get categories
app.get("/api/products/categories/all", async (req, res) => {
  try {
    const db = await createConnection();
    const [categories] = await db.execute(
      "SELECT * FROM categories ORDER BY name",
    );
    await db.end();
    res.json(categories);
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).json({ error: "Failed to fetch categories" });
  }
});

// Get products by category
app.get("/api/products/category/:categoryId", async (req, res) => {
  try {
    const db = await createConnection();
    const [products] = await db.execute(
      `
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE p.category_id = ? AND p.is_active = 1
      ORDER BY p.created_at DESC
    `,
      [req.params.categoryId],
    );
    await db.end();
    res.json(products);
  } catch (error) {
    console.error("Error fetching products by category:", error);
    res.status(500).json({ error: "Failed to fetch products" });
  }
});

// Search products
app.get("/api/products/search/:query", async (req, res) => {
  try {
    const searchQuery = `%${req.params.query}%`;
    const db = await createConnection();
    const [products] = await db.execute(
      `
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE (p.name LIKE ? OR p.description LIKE ?) AND p.is_active = 1
      ORDER BY p.created_at DESC
    `,
      [searchQuery, searchQuery],
    );
    await db.end();
    res.json(products);
  } catch (error) {
    console.error("Error searching products:", error);
    res.status(500).json({ error: "Failed to search products" });
  }
});

// Get single product
app.get("/api/products/:id", async (req, res) => {
  try {
    const db = await createConnection();
    const [products] = await db.execute(
      `
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE p.id = ? AND p.is_active = 1
    `,
      [req.params.id],
    );

    if (products.length === 0) {
      await db.end();
      return res.status(404).json({ error: "Product not found" });
    }

    await db.end();
    res.json(products[0]);
  } catch (error) {
    console.error("Error fetching product:", error);
    res.status(500).json({ error: "Failed to fetch product" });
  }
});

// ============= CART ROUTES =============

// Get cart items
app.get("/api/cart", authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    const [items] = await db.execute(
      `
      SELECT ci.*, p.name, p.price, p.image_url, p.stock_quantity
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE ci.user_id = ?
    `,
      [req.user.id],
    );
    await db.end();
    res.json(items);
  } catch (error) {
    console.error("Error fetching cart:", error);
    res.status(500).json({ error: "Failed to fetch cart" });
  }
});

// Add to cart
app.post("/api/cart/add", authenticateToken, async (req, res) => {
  const { productId, quantity } = req.body;

  try {
    const db = await createConnection();

    // Check product availability
    const [products] = await db.execute(
      "SELECT stock_quantity FROM products WHERE id = ? AND is_active = 1",
      [productId],
    );

    if (products.length === 0) {
      await db.end();
      return res.status(404).json({ error: "Product not found" });
    }

    if (products[0].stock_quantity < quantity) {
      await db.end();
      return res.status(400).json({ error: "Insufficient stock" });
    }

    // Check if item already in cart
    const [existingItems] = await db.execute(
      "SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?",
      [req.user.id, productId],
    );

    if (existingItems.length > 0) {
      // Update quantity
      await db.execute(
        "UPDATE cart_items SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?",
        [quantity, req.user.id, productId],
      );
    } else {
      // Add new item
      await db.execute(
        "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)",
        [req.user.id, productId, quantity],
      );
    }

    await db.end();
    res.json({ message: "Item added to cart" });
  } catch (error) {
    console.error("Error adding to cart:", error);
    res.status(500).json({ error: "Failed to add to cart" });
  }
});

// Update cart item quantity
app.put("/api/cart/update", authenticateToken, async (req, res) => {
  const { productId, quantity } = req.body;

  try {
    const db = await createConnection();

    if (quantity === 0) {
      // Remove item
      await db.execute(
        "DELETE FROM cart_items WHERE user_id = ? AND product_id = ?",
        [req.user.id, productId],
      );
    } else {
      // Update quantity
      await db.execute(
        "UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?",
        [quantity, req.user.id, productId],
      );
    }

    await db.end();
    res.json({ message: "Cart updated" });
  } catch (error) {
    console.error("Error updating cart:", error);
    res.status(500).json({ error: "Failed to update cart" });
  }
});

// Remove from cart
app.delete(
  "/api/cart/remove/:productId",
  authenticateToken,
  async (req, res) => {
    try {
      const db = await createConnection();
      await db.execute(
        "DELETE FROM cart_items WHERE user_id = ? AND product_id = ?",
        [req.user.id, req.params.productId],
      );
      await db.end();
      res.json({ message: "Item removed from cart" });
    } catch (error) {
      console.error("Error removing from cart:", error);
      res.status(500).json({ error: "Failed to remove from cart" });
    }
  },
);

// Clear cart
app.delete("/api/cart/clear", authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    await db.execute("DELETE FROM cart_items WHERE user_id = ?", [req.user.id]);
    await db.end();
    res.json({ message: "Cart cleared" });
  } catch (error) {
    console.error("Error clearing cart:", error);
    res.status(500).json({ error: "Failed to clear cart" });
  }
});

// ============= ORDER ROUTES =============

// Create order
app.post("/api/orders/create", authenticateToken, async (req, res) => {
  const { items, shippingAddress, paymentMethod } = req.body;

  try {
    const db = await createConnection();

    // Calculate total
    let total = 0;
    for (const item of items) {
      const [products] = await db.execute(
        "SELECT price, stock_quantity FROM products WHERE id = ?",
        [item.product_id],
      );

      if (products.length === 0 || products[0].stock_quantity < item.quantity) {
        await db.end();
        return res.status(400).json({ error: "Product not available" });
      }

      total += products[0].price * item.quantity;
    }

    // Create order
    const [orderResult] = await db.execute(
      "INSERT INTO orders (user_id, total_amount, shipping_address, payment_method, status) VALUES (?, ?, ?, ?, ?)",
      [
        req.user.id,
        total,
        JSON.stringify(shippingAddress),
        paymentMethod,
        "pending",
      ],
    );

    const orderId = orderResult.insertId;

    // Create order items and update stock
    for (const item of items) {
      const [products] = await db.execute(
        "SELECT price FROM products WHERE id = ?",
        [item.product_id],
      );

      const price = products[0].price;

      await db.execute(
        "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)",
        [orderId, item.product_id, item.quantity, price],
      );

      // Update product stock
      await db.execute(
        "UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?",
        [item.quantity, item.product_id],
      );
    }

    // Clear cart
    await db.execute("DELETE FROM cart_items WHERE user_id = ?", [req.user.id]);

    await db.end();

    res.status(201).json({
      orderId,
      total,
      message: "Order created successfully",
    });
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).json({ error: "Failed to create order" });
  }
});

// Get user orders
app.get("/api/orders/my-orders", authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    const [orders] = await db.execute(
      `
      SELECT o.*, 
        GROUP_CONCAT(CONCAT(oi.quantity, 'x ', p.name) SEPARATOR ', ') as items
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE o.user_id = ?
      GROUP BY o.id
      ORDER BY o.created_at DESC
    `,
      [req.user.id],
    );
    await db.end();
    res.json(orders);
  } catch (error) {
    console.error("Error fetching orders:", error);
    res.status(500).json({ error: "Failed to fetch orders" });
  }
});

// Get order details
app.get("/api/orders/:id", authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    const [orders] = await db.execute(
      "SELECT * FROM orders WHERE id = ? AND user_id = ?",
      [req.params.id, req.user.id],
    );

    if (orders.length === 0) {
      await db.end();
      return res.status(404).json({ error: "Order not found" });
    }

    const [orderItems] = await db.execute(
      `
      SELECT oi.*, p.name, p.image_url
      FROM order_items oi
      JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = ?
    `,
      [req.params.id],
    );

    await db.end();

    res.json({
      ...orders[0],
      items: orderItems,
    });
  } catch (error) {
    console.error("Error fetching order:", error);
    res.status(500).json({ error: "Failed to fetch order" });
  }
});

// ============= ADMIN ROUTES =============

// Get admin stats
app.get(
  "/api/admin/stats",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const db = await createConnection();

      const [totalProducts] = await db.execute(
        "SELECT COUNT(*) as count FROM products",
      );
      const [totalOrders] = await db.execute(
        "SELECT COUNT(*) as count FROM orders",
      );
      const [totalUsers] = await db.execute(
        'SELECT COUNT(*) as count FROM users WHERE role = "user"',
      );
      const [totalRevenue] = await db.execute(
        'SELECT SUM(total_amount) as total FROM orders WHERE status = "paid"',
      );
      const [recentOrders] = await db.execute(`
      SELECT o.*, u.email, u.first_name, u.last_name
      FROM orders o
      JOIN users u ON o.user_id = u.id
      ORDER BY o.created_at DESC
      LIMIT 10
    `);

      await db.end();

      res.json({
        totalProducts: totalProducts[0].count,
        totalOrders: totalOrders[0].count,
        totalUsers: totalUsers[0].count,
        totalRevenue: totalRevenue[0].total || 0,
        recentOrders,
      });
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  },
);

// Get all products for admin
app.get(
  "/api/admin/products",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const db = await createConnection();
      const [products] = await db.execute(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      ORDER BY p.created_at DESC
    `);
      await db.end();
      res.json(products);
    } catch (error) {
      console.error("Error fetching admin products:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  },
);

// Create product
app.post(
  "/api/admin/products",
  authenticateToken,
  requireAdmin,
  upload.single("image"),
  async (req, res) => {
    const { name, description, price, quantity, categoryId } = req.body;

    try {
      const db = await createConnection();
      const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

      const [result] = await db.execute(
        "INSERT INTO products (name, description, price, category_id, stock_quantity, image_url) VALUES (?, ?, ?, ?, ?, ?)",
        [name, description, price, categoryId, quantity, imageUrl],
      );

      await db.end();
      res
        .status(201)
        .json({ message: "Product created successfully", id: result.insertId });
    } catch (error) {
      console.error("Error creating product:", error);
      res.status(500).json({ error: "Failed to create product" });
    }
  },
);

// Update product
app.put(
  "/api/admin/products/:id",
  authenticateToken,
  requireAdmin,
  upload.single("image"),
  async (req, res) => {
    const { name, description, price, quantity, categoryId } = req.body;

    try {
      const db = await createConnection();

      let query =
        "UPDATE products SET name = ?, description = ?, price = ?, category_id = ?, stock_quantity = ?";
      let params = [name, description, price, categoryId, quantity];

      if (req.file) {
        query += ", image_url = ?";
        params.push(`/uploads/${req.file.filename}`);
      }

      query += " WHERE id = ?";
      params.push(req.params.id);

      await db.execute(query, params);
      await db.end();

      res.json({ message: "Product updated successfully" });
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ error: "Failed to update product" });
    }
  },
);

// Delete product
app.delete(
  "/api/admin/products/:id",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const db = await createConnection();
      await db.execute("UPDATE products SET is_active = 0 WHERE id = ?", [
        req.params.id,
      ]);
      await db.end();
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ error: "Failed to delete product" });
    }
  },
);

// Get all orders for admin
app.get(
  "/api/admin/orders",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const db = await createConnection();
      const [orders] = await db.execute(`
      SELECT o.*, u.email, u.first_name, u.last_name
      FROM orders o
      JOIN users u ON o.user_id = u.id
      ORDER BY o.created_at DESC
    `);
      await db.end();
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  },
);

// Update order status
app.put(
  "/api/admin/orders/:id",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    const { status } = req.body;

    try {
      const db = await createConnection();
      await db.execute("UPDATE orders SET status = ? WHERE id = ?", [
        status,
        req.params.id,
      ]);
      await db.end();
      res.json({ message: "Order status updated successfully" });
    } catch (error) {
      console.error("Error updating order status:", error);
      res.status(500).json({ error: "Failed to update order status" });
    }
  },
);

// ============= BLOG ROUTES =============

// Get all published blog posts
app.get("/api/blog", async (req, res) => {
  try {
    const db = await createConnection();
    const [posts] = await db.execute(`
      SELECT bp.*, u.first_name, u.last_name
      FROM blog_posts bp
      JOIN users u ON bp.author_id = u.id
      WHERE bp.is_published = 1
      ORDER BY bp.created_at DESC
    `);
    await db.end();
    res.json(posts);
  } catch (error) {
    console.error("Error fetching blog posts:", error);
    res.status(500).json({ error: "Failed to fetch blog posts" });
  }
});

// Get single blog post
app.get("/api/blog/:id", async (req, res) => {
  try {
    const db = await createConnection();
    const [posts] = await db.execute(
      `
      SELECT bp.*, u.first_name, u.last_name
      FROM blog_posts bp
      JOIN users u ON bp.author_id = u.id
      WHERE bp.id = ? AND bp.is_published = 1
    `,
      [req.params.id],
    );

    if (posts.length === 0) {
      await db.end();
      return res.status(404).json({ error: "Blog post not found" });
    }

    await db.end();
    res.json(posts[0]);
  } catch (error) {
    console.error("Error fetching blog post:", error);
    res.status(500).json({ error: "Failed to fetch blog post" });
  }
});

// Get all blog posts for admin
app.get(
  "/api/blog/admin/posts",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const db = await createConnection();
      const [posts] = await db.execute(`
      SELECT bp.*, u.first_name, u.last_name
      FROM blog_posts bp
      JOIN users u ON bp.author_id = u.id
      ORDER BY bp.created_at DESC
    `);
      await db.end();
      res.json(posts);
    } catch (error) {
      console.error("Error fetching admin blog posts:", error);
      res.status(500).json({ error: "Failed to fetch blog posts" });
    }
  },
);

// Create blog post
app.post(
  "/api/blog/admin/posts",
  authenticateToken,
  requireAdmin,
  upload.single("image"),
  async (req, res) => {
    const { title, content, excerpt, isPublished } = req.body;

    try {
      const db = await createConnection();
      const slug = title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "");
      const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

      const [result] = await db.execute(
        "INSERT INTO blog_posts (title, content, excerpt, slug, author_id, featured_image, is_published) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [title, content, excerpt, slug, req.user.id, imageUrl, isPublished],
      );

      await db.end();
      res
        .status(201)
        .json({
          message: "Blog post created successfully",
          id: result.insertId,
        });
    } catch (error) {
      console.error("Error creating blog post:", error);
      res.status(500).json({ error: "Failed to create blog post" });
    }
  },
);

// Update blog post
app.put(
  "/api/blog/admin/posts/:id",
  authenticateToken,
  requireAdmin,
  upload.single("image"),
  async (req, res) => {
    const { title, content, excerpt, isPublished } = req.body;

    try {
      const db = await createConnection();
      const slug = title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "");

      let query =
        "UPDATE blog_posts SET title = ?, content = ?, excerpt = ?, slug = ?, is_published = ?";
      let params = [title, content, excerpt, slug, isPublished];

      if (req.file) {
        query += ", featured_image = ?";
        params.push(`/uploads/${req.file.filename}`);
      }

      query += " WHERE id = ?";
      params.push(req.params.id);

      await db.execute(query, params);
      await db.end();

      res.json({ message: "Blog post updated successfully" });
    } catch (error) {
      console.error("Error updating blog post:", error);
      res.status(500).json({ error: "Failed to update blog post" });
    }
  },
);

// Delete blog post
app.delete(
  "/api/blog/admin/posts/:id",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const db = await createConnection();
      await db.execute("DELETE FROM blog_posts WHERE id = ?", [req.params.id]);
      await db.end();
      res.json({ message: "Blog post deleted successfully" });
    } catch (error) {
      console.error("Error deleting blog post:", error);
      res.status(500).json({ error: "Failed to delete blog post" });
    }
  },
);

// ============= SERVE STATIC FILES =============

// Serve static files
app.use(express.static("public"));

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`
=================================================
🟢 LOOM SOLAR E-COMMERCE SERVER RUNNING
=================================================
Port: ${PORT}
Database: MySQL2 (${dbConfig.database})
Environment: ${process.env.NODE_ENV || "development"}

✅ All Routes Working:
- Authentication: /api/auth/*
- Products: /api/products/*
- Cart: /api/cart/*
- Orders: /api/orders/*
- Admin: /api/admin/*
- Blog: /api/blog/*

📝 Sample Login Credentials:
Admin: admin@loomsolar.com / admin123
User: user@loomsolar.com / user123

🗄️ Database: Compatible with MySQL Workbench
=================================================
      `);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

startServer();
