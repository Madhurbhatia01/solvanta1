const express = require('express');
const { createConnection } = require('../config/database');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

// Dashboard stats
router.get('/stats', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const db = await createConnection();
    
    const [totalProducts] = await db.execute('SELECT COUNT(*) as count FROM products');
    const [totalOrders] = await db.execute('SELECT COUNT(*) as count FROM orders');
    const [totalUsers] = await db.execute('SELECT COUNT(*) as count FROM users WHERE role = "user"');
    const [totalRevenue] = await db.execute('SELECT SUM(total_amount) as total FROM orders WHERE status = "paid"');
    const [recentOrders] = await db.execute(`
      SELECT o.*, u.email, u.first_name, u.last_name
      FROM orders o
      JOIN users u ON o.user_id = u.id
      ORDER BY o.created_at DESC
      LIMIT 10
    `);

    await db.end();

    res.json({
      totalProducts: totalProducts[0].count,
      totalOrders: totalOrders[0].count,
      totalUsers: totalUsers[0].count,
      totalRevenue: totalRevenue[0].total || 0,
      recentOrders
    });
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Products management
router.get('/products', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const db = await createConnection();
    const [products] = await db.execute(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      ORDER BY p.created_at DESC
    `);
    await db.end();
    res.json(products);
  } catch (error) {
    console.error('Error fetching admin products:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

router.post('/products', authenticateToken, requireAdmin, upload.single('image'), async (req, res) => {
  const { name, description, price, offerPrice, quantity, categoryId, specifications } = req.body;

  try {
    const db = await createConnection();
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    const [result] = await db.execute(
      'INSERT INTO products (name, description, price, category_id, stock_quantity, image_url) VALUES (?, ?, ?, ?, ?, ?)',
      [name, description, price, categoryId, quantity, imageUrl]
    );

    await db.end();
    res.status(201).json({ message: 'Product created successfully', id: result.insertId });
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ error: 'Failed to create product' });
  }
});

router.put('/products/:id', authenticateToken, requireAdmin, upload.single('image'), async (req, res) => {
  const { name, description, price, offerPrice, quantity, categoryId, specifications } = req.body;

  try {
    const db = await createConnection();
    
    let query = 'UPDATE products SET name = ?, description = ?, price = ?, category_id = ?, stock_quantity = ?';
    let params = [name, description, price, categoryId, quantity];

    if (req.file) {
      query += ', image_url = ?';
      params.push(`/uploads/${req.file.filename}`);
    }

    query += ' WHERE id = ?';
    params.push(req.params.id);

    await db.execute(query, params);
    await db.end();

    res.json({ message: 'Product updated successfully' });
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ error: 'Failed to update product' });
  }
});

router.delete('/products/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const db = await createConnection();
    await db.execute('UPDATE products SET is_active = 0 WHERE id = ?', [req.params.id]);
    await db.end();
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

// Categories management
router.get('/categories', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const db = await createConnection();
    const [categories] = await db.execute('SELECT * FROM categories ORDER BY name');
    await db.end();
    res.json(categories);
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

router.post('/categories', authenticateToken, requireAdmin, async (req, res) => {
  const { name, description } = req.body;

  try {
    const db = await createConnection();
    const [result] = await db.execute(
      'INSERT INTO categories (name, description) VALUES (?, ?)',
      [name, description]
    );
    await db.end();
    res.status(201).json({ message: 'Category created successfully', id: result.insertId });
  } catch (error) {
    console.error('Error creating category:', error);
    res.status(500).json({ error: 'Failed to create category' });
  }
});

// Orders management
router.get('/orders', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const db = await createConnection();
    const [orders] = await db.execute(`
      SELECT o.*, u.email, u.first_name, u.last_name
      FROM orders o
      JOIN users u ON o.user_id = u.id
      ORDER BY o.created_at DESC
    `);
    await db.end();
    res.json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

router.put('/orders/:id/status', authenticateToken, requireAdmin, async (req, res) => {
  const { status } = req.body;

  try {
    const db = await createConnection();
    await db.execute('UPDATE orders SET status = ? WHERE id = ?', [status, req.params.id]);
    await db.end();
    res.json({ message: 'Order status updated successfully' });
  } catch (error) {
    console.error('Error updating order status:', error);
    res.status(500).json({ error: 'Failed to update order status' });
  }
});

module.exports = router;
