const express = require('express');
const { createConnection } = require('../config/database');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

// Get all blog posts
router.get('/', async (req, res) => {
  try {
    const db = await createConnection();
    const [posts] = await db.execute(`
      SELECT bp.*, u.first_name, u.last_name
      FROM blog_posts bp
      JOIN users u ON bp.author_id = u.id
      WHERE bp.is_published = 1
      ORDER BY bp.created_at DESC
    `);
    await db.end();
    res.json(posts);
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    res.status(500).json({ error: 'Failed to fetch blog posts' });
  }
});

// Get single blog post
router.get('/:id', async (req, res) => {
  try {
    const db = await createConnection();
    const [posts] = await db.execute(`
      SELECT bp.*, u.first_name, u.last_name
      FROM blog_posts bp
      JOIN users u ON bp.author_id = u.id
      WHERE bp.id = ? AND bp.is_published = 1
    `, [req.params.id]);

    if (posts.length === 0) {
      await db.end();
      return res.status(404).json({ error: 'Blog post not found' });
    }

    await db.end();
    res.json(posts[0]);
  } catch (error) {
    console.error('Error fetching blog post:', error);
    res.status(500).json({ error: 'Failed to fetch blog post' });
  }
});

// Admin routes
router.get('/admin/posts', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const db = await createConnection();
    const [posts] = await db.execute(`
      SELECT bp.*, u.first_name, u.last_name
      FROM blog_posts bp
      JOIN users u ON bp.author_id = u.id
      ORDER BY bp.created_at DESC
    `);
    await db.end();
    res.json(posts);
  } catch (error) {
    console.error('Error fetching admin blog posts:', error);
    res.status(500).json({ error: 'Failed to fetch blog posts' });
  }
});

router.post('/admin/posts', authenticateToken, requireAdmin, upload.single('image'), async (req, res) => {
  const { title, content, excerpt, tags } = req.body;

  try {
    const db = await createConnection();
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    const [result] = await db.execute(
      'INSERT INTO blog_posts (title, content, excerpt, image_url, tags, author_id) VALUES (?, ?, ?, ?, ?, ?)',
      [title, content, excerpt, imageUrl, tags, req.user.id]
    );

    await db.end();
    res.status(201).json({ message: 'Blog post created successfully', id: result.insertId });
  } catch (error) {
    console.error('Error creating blog post:', error);
    res.status(500).json({ error: 'Failed to create blog post' });
  }
});

router.put('/admin/posts/:id', authenticateToken, requireAdmin, upload.single('image'), async (req, res) => {
  const { title, content, excerpt, tags, isPublished } = req.body;

  try {
    const db = await createConnection();
    
    let query = 'UPDATE blog_posts SET title = ?, content = ?, excerpt = ?, tags = ?, is_published = ?';
    let params = [title, content, excerpt, tags, isPublished === 'true' ? 1 : 0];

    if (req.file) {
      query += ', image_url = ?';
      params.push(`/uploads/${req.file.filename}`);
    }

    query += ' WHERE id = ?';
    params.push(req.params.id);

    await db.execute(query, params);
    await db.end();

    res.json({ message: 'Blog post updated successfully' });
  } catch (error) {
    console.error('Error updating blog post:', error);
    res.status(500).json({ error: 'Failed to update blog post' });
  }
});

router.delete('/admin/posts/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const db = await createConnection();
    await db.execute('DELETE FROM blog_posts WHERE id = ?', [req.params.id]);
    await db.end();
    res.json({ message: 'Blog post deleted successfully' });
  } catch (error) {
    console.error('Error deleting blog post:', error);
    res.status(500).json({ error: 'Failed to delete blog post' });
  }
});

module.exports = router;
