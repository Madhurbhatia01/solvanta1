const express = require('express');
const { createConnection } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get cart items
router.get('/', authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    const [items] = await db.execute(`
      SELECT ci.*, p.name, p.price, p.image_url, p.stock_quantity
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE ci.user_id = ?
    `, [req.user.id]);
    await db.end();
    res.json(items);
  } catch (error) {
    console.error('Error fetching cart:', error);
    res.status(500).json({ error: 'Failed to fetch cart' });
  }
});

// Add to cart
router.post('/add', authenticateToken, async (req, res) => {
  const { productId, quantity } = req.body;

  try {
    const db = await createConnection();
    
    // Check product availability
    const [products] = await db.execute(
      'SELECT stock_quantity FROM products WHERE id = ? AND is_active = 1',
      [productId]
    );

    if (products.length === 0) {
      await db.end();
      return res.status(404).json({ error: 'Product not found' });
    }

    if (products[0].stock_quantity < quantity) {
      await db.end();
      return res.status(400).json({ error: 'Insufficient stock' });
    }

    // Check if item already in cart
    const [existingItems] = await db.execute(
      'SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?',
      [req.user.id, productId]
    );

    if (existingItems.length > 0) {
      // Update quantity
      await db.execute(
        'UPDATE cart_items SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?',
        [quantity, req.user.id, productId]
      );
    } else {
      // Add new item
      await db.execute(
        'INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)',
        [req.user.id, productId, quantity]
      );
    }

    await db.end();
    res.json({ message: 'Item added to cart' });
  } catch (error) {
    console.error('Error adding to cart:', error);
    res.status(500).json({ error: 'Failed to add to cart' });
  }
});

// Update cart item quantity
router.put('/update', authenticateToken, async (req, res) => {
  const { productId, quantity } = req.body;

  if (quantity < 0) {
    return res.status(400).json({ error: 'Quantity cannot be negative' });
  }

  try {
    const db = await createConnection();
    
    if (quantity === 0) {
      // Remove item
      await db.execute(
        'DELETE FROM cart_items WHERE user_id = ? AND product_id = ?',
        [req.user.id, productId]
      );
    } else {
      // Update quantity
      await db.execute(
        'UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?',
        [quantity, req.user.id, productId]
      );
    }

    await db.end();
    res.json({ message: 'Cart updated' });
  } catch (error) {
    console.error('Error updating cart:', error);
    res.status(500).json({ error: 'Failed to update cart' });
  }
});

// Remove from cart
router.delete('/remove/:productId', authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    await db.execute(
      'DELETE FROM cart_items WHERE user_id = ? AND product_id = ?',
      [req.user.id, req.params.productId]
    );
    await db.end();
    res.json({ message: 'Item removed from cart' });
  } catch (error) {
    console.error('Error removing from cart:', error);
    res.status(500).json({ error: 'Failed to remove from cart' });
  }
});

// Clear cart
router.delete('/clear', authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    await db.execute('DELETE FROM cart_items WHERE user_id = ?', [req.user.id]);
    await db.end();
    res.json({ message: 'Cart cleared' });
  } catch (error) {
    console.error('Error clearing cart:', error);
    res.status(500).json({ error: 'Failed to clear cart' });
  }
});

module.exports = router;
