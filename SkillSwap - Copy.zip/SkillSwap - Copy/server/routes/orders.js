const express = require('express');
const { createConnection } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');
const Razorpay = require('razorpay');

const router = express.Router();

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || 'your_key_id',
  key_secret: process.env.RAZORPAY_KEY_SECRET || 'your_key_secret'
});

// Create order
router.post('/create', authenticateToken, async (req, res) => {
  const { items, shippingAddress, paymentMethod } = req.body;

  try {
    const db = await createConnection();
    
    // Calculate total
    let total = 0;
    for (const item of items) {
      const [products] = await db.execute(
        'SELECT price, stock_quantity FROM products WHERE id = ?',
        [item.product_id]
      );
      
      if (products.length === 0 || products[0].stock_quantity < item.quantity) {
        await db.end();
        return res.status(400).json({ error: 'Product not available' });
      }
      
      const price = products[0].price;
      total += price * item.quantity;
    }

    // Create order
    const [orderResult] = await db.execute(
      'INSERT INTO orders (user_id, total_amount, shipping_address, payment_method, status) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, total, JSON.stringify(shippingAddress), paymentMethod, 'pending']
    );

    const orderId = orderResult.insertId;

    // Create order items
    for (const item of items) {
      const [products] = await db.execute(
        'SELECT price FROM products WHERE id = ?',
        [item.product_id]
      );
      
      const price = products[0].price;
      
      await db.execute(
        'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
        [orderId, item.product_id, item.quantity, price]
      );

      // Update product quantity
      await db.execute(
        'UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?',
        [item.quantity, item.product_id]
      );
    }

    // Clear cart
    await db.execute('DELETE FROM cart_items WHERE user_id = ?', [req.user.id]);

    await db.end();

    res.status(201).json({
      orderId,
      total,
      message: 'Order created successfully'
    });
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

// Create Razorpay order
router.post('/razorpay/create', authenticateToken, async (req, res) => {
  const { amount } = req.body;

  try {
    const options = {
      amount: amount * 100, // amount in paise
      currency: 'INR',
      receipt: `order_${Date.now()}`
    };

    const order = await razorpay.orders.create(options);
    res.json(order);
  } catch (error) {
    console.error('Error creating Razorpay order:', error);
    res.status(500).json({ error: 'Failed to create payment order' });
  }
});

// Verify Razorpay payment
router.post('/razorpay/verify', authenticateToken, async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, order_id } = req.body;

  try {
    const crypto = require('crypto');
    const hmac = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET);
    hmac.update(razorpay_order_id + '|' + razorpay_payment_id);
    const generated_signature = hmac.digest('hex');

    if (generated_signature === razorpay_signature) {
      // Payment verified, update order status
      const db = await createConnection();
      await db.execute(
        'UPDATE orders SET status = ?, payment_id = ? WHERE id = ? AND user_id = ?',
        ['paid', razorpay_payment_id, order_id, req.user.id]
      );
      await db.end();

      res.json({ message: 'Payment verified successfully' });
    } else {
      res.status(400).json({ error: 'Payment verification failed' });
    }
  } catch (error) {
    console.error('Error verifying payment:', error);
    res.status(500).json({ error: 'Payment verification failed' });
  }
});

// Get user orders
router.get('/my-orders', authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    const [orders] = await db.execute(`
      SELECT o.*, 
        GROUP_CONCAT(CONCAT(oi.quantity, 'x ', p.name) SEPARATOR ', ') as items
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE o.user_id = ?
      GROUP BY o.id
      ORDER BY o.created_at DESC
    `, [req.user.id]);
    await db.end();
    res.json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// Get order details
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const db = await createConnection();
    const [orders] = await db.execute(
      'SELECT * FROM orders WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );

    if (orders.length === 0) {
      await db.end();
      return res.status(404).json({ error: 'Order not found' });
    }

    const [orderItems] = await db.execute(`
      SELECT oi.*, p.name, p.image_url
      FROM order_items oi
      JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = ?
    `, [req.params.id]);

    await db.end();

    res.json({
      ...orders[0],
      items: orderItems
    });
  } catch (error) {
    console.error('Error fetching order:', error);
    res.status(500).json({ error: 'Failed to fetch order' });
  }
});

module.exports = router;
