const express = require('express');
const { createConnection } = require('../config/database');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Get all products
router.get('/', async (req, res) => {
  try {
    const db = await createConnection();
    const [products] = await db.execute(`
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE p.is_active = 1
      ORDER BY p.created_at DESC
    `);
    await db.end();
    res.json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Get products by category
router.get('/category/:categoryId', async (req, res) => {
  try {
    const db = await createConnection();
    const [products] = await db.execute(`
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE p.category_id = ? AND p.is_active = 1
      ORDER BY p.created_at DESC
    `, [req.params.categoryId]);
    await db.end();
    res.json(products);
  } catch (error) {
    console.error('Error fetching products by category:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Get single product by ID (moved before category route)
router.get('/product/:id', async (req, res) => {
  try {
    const db = await createConnection();
    const [products] = await db.execute(`
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE p.id = ? AND p.is_active = 1
    `, [req.params.id]);
    
    if (products.length === 0) {
      await db.end();
      return res.status(404).json({ error: 'Product not found' });
    }

    await db.end();
    res.json(products[0]);
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

// Get categories
router.get('/categories/all', async (req, res) => {
  try {
    const db = await createConnection();
    const [categories] = await db.execute('SELECT * FROM categories ORDER BY name');
    await db.end();
    res.json(categories);
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

// Search products
router.get('/search/:query', async (req, res) => {
  try {
    const searchQuery = `%${req.params.query}%`;
    const db = await createConnection();
    const [products] = await db.execute(`
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE (p.name LIKE ? OR p.description LIKE ?) AND p.is_active = 1
      ORDER BY p.created_at DESC
    `, [searchQuery, searchQuery]);
    await db.end();
    res.json(products);
  } catch (error) {
    console.error('Error searching products:', error);
    res.status(500).json({ error: 'Failed to search products' });
  }
});

// Get single product by ID - must be at the end to avoid conflicts
router.get('/:id', async (req, res) => {
  try {
    const db = await createConnection();
    const [products] = await db.execute(`
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      WHERE p.id = ? AND p.is_active = 1
    `, [req.params.id]);
    
    if (products.length === 0) {
      await db.end();
      return res.status(404).json({ error: 'Product not found' });
    }

    await db.end();
    res.json(products[0]);
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

module.exports = router;
