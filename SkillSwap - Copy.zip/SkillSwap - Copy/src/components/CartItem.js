import React from 'react';
import { useCart } from '../hooks/useCart';

const CartItem = ({ item }) => {
  const { updateQuantity, removeFromCart } = useCart();

  const handleQuantityChange = (newQuantity) => {
    if (newQuantity < 0) return;
    updateQuantity(item.product_id, newQuantity);
  };

  const price = item.offer_price || item.price;
  const totalPrice = price * item.quantity;

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-4">
      <div className="flex items-center space-x-4">
        <img
          src={item.image_url}
          alt={item.name}
          className="w-16 h-16 object-cover rounded"
        />
        
        <div className="flex-1">
          <h3 className="font-semibold text-gray-800">{item.name}</h3>
          <p className="text-sm text-gray-600">
            ₹{price} each
          </p>
          <p className="text-sm text-gray-500">
            Stock: {item.stock_quantity}
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => handleQuantityChange(item.quantity - 1)}
            className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300"
          >
            <i className="fas fa-minus text-sm"></i>
          </button>
          
          <span className="w-8 text-center font-semibold">
            {item.quantity}
          </span>
          
          <button
            onClick={() => handleQuantityChange(item.quantity + 1)}
            disabled={item.quantity >= item.stock_quantity}
            className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 disabled:opacity-50"
          >
            <i className="fas fa-plus text-sm"></i>
          </button>
        </div>

        <div className="text-right">
          <p className="font-semibold text-loom-green">
            ₹{totalPrice.toFixed(2)}
          </p>
        </div>

        <button
          onClick={() => removeFromCart(item.product_id)}
          className="text-red-500 hover:text-red-700"
        >
          <i className="fas fa-trash"></i>
        </button>
      </div>
    </div>
  );
};

export default CartItem;
