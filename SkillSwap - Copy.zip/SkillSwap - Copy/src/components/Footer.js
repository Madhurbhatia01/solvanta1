import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../utils/api';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [isSubscribing, setIsSubscribing] = useState(false);

  const handleSubscribe = async (e) => {
    e.preventDefault();
    setIsSubscribing(true);
    
    try {
      await api.post('/newsletter/subscribe', { email });
      alert('Successfully subscribed to newsletter!');
      setEmail('');
    } catch (error) {
      alert('Subscription failed. Please try again.');
    } finally {
      setIsSubscribing(false);
    }
  };

  return (
    <footer className="bg-loom-dark text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <div className="bg-loom-green text-white px-3 py-1 rounded-lg font-bold text-xl">
                LOOM
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              India's No.1 Solar Company in Residential Solar!
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-loom-green">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-loom-green">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-loom-green">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-loom-green">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>

          {/* Main Menu */}
          <div>
            <h3 className="text-lg font-semibold mb-4">MAIN MENU</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-loom-green">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/shop" className="text-gray-300 hover:text-loom-green">
                  Shop
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-loom-green">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-300 hover:text-loom-green">
                  Learn
                </Link>
              </li>
            </ul>
          </div>

          {/* Footer Menu */}
          <div>
            <h3 className="text-lg font-semibold mb-4">FOOTER MENU</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-gray-300 hover:text-loom-green">
                  About
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-loom-green">
                  Store Locator
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-loom-green">
                  Certificates
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-loom-green">
                  Franchise
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-loom-green">
                  Careers
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-semibold mb-4">SUBSCRIBE</h3>
            <p className="text-gray-300 mb-4">
              Leave your email address for news updates
            </p>
            <form onSubmit={handleSubscribe}>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 px-4 py-2 bg-gray-700 text-white rounded-l-lg focus:outline-none focus:ring-2 focus:ring-loom-green"
                  required
                />
                <button
                  type="submit"
                  disabled={isSubscribing}
                  className="bg-loom-green text-white px-6 py-2 rounded-r-lg hover:bg-green-600 disabled:opacity-50"
                >
                  {isSubscribing ? 'Loading...' : 'Subscribe'}
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Company Stats */}
        <div className="mt-12 pt-8 border-t border-gray-700">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-2xl font-bold text-loom-green mb-2">
                <i className="fas fa-building mr-2"></i>
                Solar Company
              </div>
              <p className="text-gray-300">India's No.1 Solar Company in Residential Solar!</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-loom-green mb-2">
                <i className="fas fa-home mr-2"></i>
                50,000 Homes
              </div>
              <p className="text-gray-300">Made Solar Powered In India including remote & hilly areas</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-loom-green mb-2">
                <i className="fas fa-star mr-2"></i>
                7 Years of Trust
              </div>
              <p className="text-gray-300">Celebrating the excellence in Manufacturing, Marketing, Distribution & Service.</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-loom-green mb-2">
                <i className="fas fa-headset mr-2"></i>
                Instant Service
              </div>
              <p className="text-gray-300">Contact us by Chat, Email, Phone, WhatsApp</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="bg-gray-800 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400">
              © 2024 Loom Solar. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-loom-green">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-loom-green">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-loom-green">
                Refund Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
