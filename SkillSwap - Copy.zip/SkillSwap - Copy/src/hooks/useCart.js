import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './useAuth';
import { api } from '../utils/api';

const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated) {
      fetchCartItems();
    } else {
      setCartItems([]);
    }
  }, [isAuthenticated]);

  const fetchCartItems = async () => {
    try {
      setLoading(true);
      const response = await api.get('/cart');
      setCartItems(response.data);
    } catch (error) {
      console.error('Error fetching cart items:', error);
      setError('Failed to fetch cart items');
    } finally {
      setLoading(false);
    }
  };

  const addToCart = async (productId, quantity = 1) => {
    try {
      setError(null);
      await api.post('/cart/add', { productId, quantity });
      await fetchCartItems();
      showSuccessMessage('Item added to cart');
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Failed to add item to cart';
      setError(errorMessage);
      showErrorMessage(errorMessage);
      throw error;
    }
  };

  const updateQuantity = async (productId, quantity) => {
    try {
      setError(null);
      await api.put('/cart/update', { productId, quantity });
      await fetchCartItems();
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Failed to update cart';
      setError(errorMessage);
      showErrorMessage(errorMessage);
    }
  };

  const removeFromCart = async (productId) => {
    try {
      setError(null);
      await api.delete(`/cart/remove/${productId}`);
      await fetchCartItems();
      showSuccessMessage('Item removed from cart');
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Failed to remove item';
      setError(errorMessage);
      showErrorMessage(errorMessage);
    }
  };

  const clearCart = async () => {
    try {
      setError(null);
      await api.delete('/cart/clear');
      setCartItems([]);
      showSuccessMessage('Cart cleared');
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Failed to clear cart';
      setError(errorMessage);
      showErrorMessage(errorMessage);
    }
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => {
      const price = item.offer_price || item.price;
      return total + (price * item.quantity);
    }, 0);
  };

  const getCartItemCount = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };

  const isInCart = (productId) => {
    return cartItems.some(item => item.product_id === productId);
  };

  const getCartItemQuantity = (productId) => {
    const item = cartItems.find(item => item.product_id === productId);
    return item ? item.quantity : 0;
  };

  // Helper functions for user feedback
  const showSuccessMessage = (message) => {
    // You can replace this with a proper toast notification system
    console.log('Success:', message);
  };

  const showErrorMessage = (message) => {
    // You can replace this with a proper toast notification system
    console.error('Error:', message);
  };

  const value = {
    cartItems,
    loading,
    error,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    fetchCartItems,
    getCartTotal,
    getCartItemCount,
    isInCart,
    getCartItemQuantity,
    setError
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};

export default CartContext;
