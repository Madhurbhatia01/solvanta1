import React from 'react';

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-loom-dark text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">About Us</h1>
            <p className="text-xl md:text-2xl">
              India's leading solar company revolutionizing renewable energy
            </p>
          </div>
        </div>
      </div>

      {/* Company Overview */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Story</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Loom Solar is a leading manufacturer of Solar Power Generating Systems/Parts, founded in 2018 by
              two brothers Amod and Amol Anand. With continuous research and development effort of our team of
              150+ highly skilled individuals, and 2 manufacturing units, we manufacture the cutting edge solar
              products including solar panel, battery and inverter in India and sell them globally to more than 10
              countries through a vast network of 10,000+ dealers and have over 50,000 satisfied customers.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-loom-green rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-bullseye text-white text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Our Mission</h3>
              <p className="text-gray-600">
                To make clean, affordable solar energy accessible to every household and business in India,
                driving the nation's transition to sustainable energy while creating economic opportunities
                and environmental benefits for all.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-loom-green rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-eye text-white text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Our Vision</h3>
              <p className="text-gray-600">
                To be the most trusted and innovative solar company in India, leading the renewable energy
                revolution through cutting-edge technology, exceptional service, and sustainable solutions
                that power a cleaner future.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Key Statistics */}
      <section className="py-16 bg-loom-dark text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">We're proud to be recognized</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-loom-green mb-2">
                <i className="fas fa-building mr-2"></i>
                #1
              </div>
              <p className="text-gray-300">Solar Company</p>
              <p className="text-sm text-gray-400">India's No.1 Solar Company in Residential Solar!</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-loom-green mb-2">
                <i className="fas fa-home mr-2"></i>
                50,000+
              </div>
              <p className="text-gray-300">Homes Powered</p>
              <p className="text-sm text-gray-400">Made Solar Powered In India including remote & hilly areas</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-loom-green mb-2">
                <i className="fas fa-star mr-2"></i>
                7
              </div>
              <p className="text-gray-300">Years of Trust</p>
              <p className="text-sm text-gray-400">Celebrating excellence in Manufacturing, Marketing, Distribution & Service</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-loom-green mb-2">
                <i className="fas fa-headset mr-2"></i>
                24/7
              </div>
              <p className="text-gray-300">Instant Service</p>
              <p className="text-sm text-gray-400">Contact us by Chat, Email, Phone, WhatsApp</p>
            </div>
          </div>
        </div>
      </section>

      {/* Global Presence */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Global Presence</h2>
            <p className="text-lg text-gray-600">
              We are an Authorised Economic Operator (AEO) license holder given by
              World Customs Organisation to facilitate global trade. We are among
              India's leading manufacturer of solar power generating systems having
              exports in more than 10 countries.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <div className="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <i className="fas fa-globe text-gray-400 text-6xl mb-4"></i>
                <p className="text-gray-600">World map showing our global presence</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Awards & Recognition */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Awards & Recognition</h2>
            <p className="text-lg text-gray-600">
              We're proud to be recognized by leading media houses and industry bodies
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 items-center justify-center">
            <div className="text-center">
              <div className="h-20 bg-gray-200 rounded-lg flex items-center justify-center mb-4">
                <span className="text-lg font-bold text-gray-600">The Economic Times</span>
              </div>
            </div>
            <div className="text-center">
              <div className="h-20 bg-gray-200 rounded-lg flex items-center justify-center mb-4">
                <span className="text-lg font-bold text-gray-600">PV Magazine</span>
              </div>
            </div>
            <div className="text-center">
              <div className="h-20 bg-gray-200 rounded-lg flex items-center justify-center mb-4">
                <span className="text-lg font-bold text-gray-600">AAJ TAK</span>
              </div>
            </div>
            <div className="text-center">
              <div className="h-20 bg-gray-200 rounded-lg flex items-center justify-center mb-4">
                <span className="text-lg font-bold text-gray-600">BBC News</span>
              </div>
            </div>
            <div className="text-center">
              <div className="h-20 bg-gray-200 rounded-lg flex items-center justify-center mb-4">
                <span className="text-lg font-bold text-gray-600">The Hindu</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Leadership Team</h2>
            <p className="text-lg text-gray-600">
              Meet the visionary leaders driving India's solar revolution
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <div className="w-32 h-32 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                <i className="fas fa-user text-gray-400 text-4xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Amod Anand</h3>
              <p className="text-loom-green font-semibold mb-2">Co-Founder & CEO</p>
              <p className="text-gray-600">
                Visionary leader with extensive experience in renewable energy and business development.
                Passionate about making solar energy accessible to every Indian household.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <div className="w-32 h-32 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                <i className="fas fa-user text-gray-400 text-4xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Amol Anand</h3>
              <p className="text-loom-green font-semibold mb-2">Co-Founder & CTO</p>
              <p className="text-gray-600">
                Technology expert driving innovation in solar products and manufacturing processes.
                Committed to developing cutting-edge solutions for India's energy needs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Why Choose Loom Solar?</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-loom-green rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-certificate text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Quality Assurance</h3>
              <p className="text-gray-600">
                All our products undergo rigorous testing and come with comprehensive warranties
                to ensure long-lasting performance.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-loom-green rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-tools text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Expert Installation</h3>
              <p className="text-gray-600">
                Our certified technicians provide professional installation services across India
                with ongoing support and maintenance.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-loom-green rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-rupee-sign text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Affordable Pricing</h3>
              <p className="text-gray-600">
                We offer competitive pricing with flexible EMI options to make solar energy
                accessible to everyone.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-loom-green text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Go Solar?</h2>
          <p className="text-xl mb-8">
            Join thousands of satisfied customers who have made the switch to clean, affordable solar energy.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-loom-green px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Get Free Quote
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-loom-green transition-colors">
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
