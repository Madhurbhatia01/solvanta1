import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../utils/api';

const BlogPost = () => {
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const [relatedPosts, setRelatedPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchPost();
    fetchRelatedPosts();
  }, [id]);

  const fetchPost = async () => {
    try {
      const response = await api.get(`/blog/${id}`);
      setPost(response.data);
    } catch (error) {
      setError('Post not found');
    } finally {
      setLoading(false);
    }
  };

  const fetchRelatedPosts = async () => {
    try {
      const response = await api.get('/blog');
      const filtered = response.data.filter(p => p.id !== parseInt(id)).slice(0, 3);
      setRelatedPosts(filtered);
    } catch (error) {
      console.error('Error fetching related posts:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-loom-green"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Post Not Found</h2>
          <Link to="/blog" className="text-loom-green hover:underline">
            Return to Blog
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-gray-500">
            <li>
              <Link to="/" className="hover:text-loom-green">Home</Link>
            </li>
            <li>
              <i className="fas fa-chevron-right"></i>
            </li>
            <li>
              <Link to="/blog" className="hover:text-loom-green">Blog</Link>
            </li>
            <li>
              <i className="fas fa-chevron-right"></i>
            </li>
            <li className="text-gray-800 truncate">{post.title}</li>
          </ol>
        </nav>

        {/* Article */}
        <article className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <img
            src={post.image_url}
            alt={post.title}
            className="w-full h-64 md:h-96 object-cover"
          />
          
          <div className="p-8">
            <div className="mb-6">
              <div className="text-sm text-loom-green font-semibold mb-2">
                LOOM SOLAR
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
                {post.title}
              </h1>
              <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                <span>By {post.first_name} {post.last_name}</span>
                <span>•</span>
                <span>{new Date(post.created_at).toLocaleDateString()}</span>
                <span>•</span>
                <span>5 min read</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {post.tags.split(',').map((tag, index) => (
                  <span
                    key={index}
                    className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                  >
                    {tag.trim()}
                  </span>
                ))}
              </div>
            </div>

            <div className="prose prose-lg max-w-none">
              {post.content.split('\n').map((paragraph, index) => {
                if (paragraph.trim() === '') return null;
                
                if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                  return (
                    <h3 key={index} className="text-xl font-bold text-gray-800 mt-6 mb-3">
                      {paragraph.slice(2, -2)}
                    </h3>
                  );
                }
                
                if (paragraph.startsWith('1. ') || paragraph.startsWith('2. ') || paragraph.startsWith('3. ')) {
                  return (
                    <p key={index} className="text-gray-700 mb-4 pl-4">
                      <strong>{paragraph.substring(0, 3)}</strong>
                      {paragraph.substring(3)}
                    </p>
                  );
                }
                
                return (
                  <p key={index} className="text-gray-700 mb-4 leading-relaxed">
                    {paragraph}
                  </p>
                );
              })}
            </div>

            {/* Social Sharing */}
            <div className="mt-8 pt-6 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">Share this article</h3>
                  <div className="flex space-x-4">
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                      <i className="fab fa-facebook-f mr-2"></i>
                      Facebook
                    </button>
                    <button className="bg-blue-400 text-white px-4 py-2 rounded-lg hover:bg-blue-500 transition-colors">
                      <i className="fab fa-twitter mr-2"></i>
                      Twitter
                    </button>
                    <button className="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-800 transition-colors">
                      <i className="fab fa-linkedin-in mr-2"></i>
                      LinkedIn
                    </button>
                    <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                      <i className="fab fa-whatsapp mr-2"></i>
                      WhatsApp
                    </button>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500">Found this helpful?</p>
                  <div className="flex space-x-2 mt-2">
                    <button className="text-loom-green hover:text-green-600">
                      <i className="fas fa-thumbs-up"></i>
                    </button>
                    <button className="text-gray-400 hover:text-gray-600">
                      <i className="fas fa-thumbs-down"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </article>

        {/* Author Info */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
              <i className="fas fa-user text-gray-400 text-xl"></i>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">
                {post.first_name} {post.last_name}
              </h3>
              <p className="text-gray-600">
                Solar energy expert and content writer at Loom Solar. Passionate about renewable energy 
                and helping customers make informed decisions about solar solutions.
              </p>
            </div>
          </div>
        </div>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Related Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedPosts.map(relatedPost => (
                <div key={relatedPost.id} className="border-b md:border-b-0 pb-6 md:pb-0">
                  <Link to={`/blog/${relatedPost.id}`}>
                    <img
                      src={relatedPost.image_url}
                      alt={relatedPost.title}
                      className="w-full h-32 object-cover rounded-lg mb-3"
                    />
                  </Link>
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">
                    <Link to={`/blog/${relatedPost.id}`} className="hover:text-loom-green">
                      {relatedPost.title}
                    </Link>
                  </h3>
                  <p className="text-gray-600 text-sm mb-2">
                    {relatedPost.excerpt.substring(0, 80)}...
                  </p>
                  <div className="text-xs text-gray-500">
                    {new Date(relatedPost.created_at).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlogPost;
