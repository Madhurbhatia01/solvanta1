import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import { useAuth } from '../hooks/useAuth';
import CartItem from '../components/CartItem';
import { api } from '../utils/api';

const Cart = () => {
  const { cartItems, clearCart, loading } = useCart();
  const { user } = useAuth();
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [shippingInfo, setShippingInfo] = useState({
    fullName: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    phone: ''
  });

  const subtotal = cartItems.reduce((total, item) => {
    const price = item.price;
    return total + (price * item.quantity);
  }, 0);

  const shipping = subtotal > 5000 ? 0 : 500;
  const total = subtotal + shipping;

  const handleInputChange = (e) => {
    setShippingInfo({
      ...shippingInfo,
      [e.target.name]: e.target.value
    });
  };

  const handleCheckout = async () => {
    if (!user) {
      alert('Please login to proceed');
      return;
    }

    if (cartItems.length === 0) {
      alert('Your cart is empty');
      return;
    }

    // Validate shipping info
    const requiredFields = ['fullName', 'address', 'city', 'state', 'pincode', 'phone'];
    const missingFields = requiredFields.filter(field => !shippingInfo[field]);
    if (missingFields.length > 0) {
      alert(`Please fill in: ${missingFields.join(', ')}`);
      return;
    }

    setCheckoutLoading(true);
    try {
      // Create order
      const orderData = {
        items: cartItems.map(item => ({
          product_id: item.product_id,
          quantity: item.quantity
        })),
        shippingAddress: shippingInfo,
        paymentMethod: 'razorpay'
      };

      const orderResponse = await api.post('/orders/create', orderData);
      const { orderId } = orderResponse.data;

      // Create Razorpay order
      const razorpayResponse = await api.post('/orders/razorpay/create', {
        amount: total
      });

      const options = {
        key: process.env.REACT_APP_RAZORPAY_KEY_ID || 'rzp_test_key',
        amount: razorpayResponse.data.amount,
        currency: razorpayResponse.data.currency,
        name: 'Loom Solar',
        description: 'Solar Products Purchase',
        order_id: razorpayResponse.data.id,
        handler: async (response) => {
          try {
            await api.post('/orders/razorpay/verify', {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              order_id: orderId
            });
            alert('Payment successful! Order placed.');
            clearCart();
            window.location.href = '/dashboard';
          } catch (error) {
            alert('Payment verification failed');
          }
        },
        prefill: {
          name: shippingInfo.fullName,
          email: user.email,
          contact: shippingInfo.phone
        },
        theme: {
          color: '#22C55E'
        }
      };

      const razorpay = new window.Razorpay(options);
      razorpay.open();
    } catch (error) {
      console.error('Checkout error:', error);
      alert('Checkout failed. Please try again.');
    } finally {
      setCheckoutLoading(false);
    }
  };

  const handleBuyNow = async (item) => {
    if (!user) {
      alert('Please login to purchase');
      return;
    }

    setCheckoutLoading(true);
    try {
      const price = item.offer_price || item.price;
      const amount = price * item.quantity;

      // Create single item order
      const orderData = {
        items: [{
          product_id: item.product_id,
          quantity: item.quantity
        }],
        shippingAddress: shippingInfo,
        paymentMethod: 'razorpay'
      };

      const orderResponse = await api.post('/orders/create', orderData);
      const { orderId } = orderResponse.data;

      // Create Razorpay order
      const razorpayResponse = await api.post('/orders/razorpay/create', {
        amount: amount + (amount > 5000 ? 0 : 500)
      });

      const options = {
        key: process.env.REACT_APP_RAZORPAY_KEY_ID || 'rzp_test_key',
        amount: razorpayResponse.data.amount,
        currency: razorpayResponse.data.currency,
        name: 'Loom Solar',
        description: item.name,
        order_id: razorpayResponse.data.id,
        handler: async (response) => {
          try {
            await api.post('/orders/razorpay/verify', {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              order_id: orderId
            });
            alert('Payment successful! Order placed.');
            window.location.href = '/dashboard';
          } catch (error) {
            alert('Payment verification failed');
          }
        },
        prefill: {
          name: shippingInfo.fullName,
          email: user.email,
          contact: shippingInfo.phone
        },
        theme: {
          color: '#22C55E'
        }
      };

      const razorpay = new window.Razorpay(options);
      razorpay.open();
    } catch (error) {
      console.error('Buy now error:', error);
      alert('Purchase failed. Please try again.');
    } finally {
      setCheckoutLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-loom-green"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Shopping Cart</h1>

        {cartItems.length === 0 ? (
          <div className="text-center py-12">
            <i className="fas fa-shopping-cart text-gray-400 text-6xl mb-4"></i>
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              Your cart is empty
            </h3>
            <p className="text-gray-500 mb-6">
              Add some solar products to get started
            </p>
            <Link
              to="/shop"
              className="bg-loom-green text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors"
            >
              Continue Shopping
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 className="text-xl font-semibold mb-4">Cart Items</h2>
                {cartItems.map(item => (
                  <div key={item.product_id}>
                    <CartItem item={item} />
                    <div className="flex justify-end mt-2 mb-4">
                      <button
                        onClick={() => handleBuyNow(item)}
                        disabled={checkoutLoading}
                        className="bg-loom-green text-white px-4 py-2 rounded-lg hover:bg-green-600 disabled:opacity-50 transition-colors"
                      >
                        Buy This Item Now
                      </button>
                    </div>
                  </div>
                ))}
                <div className="flex justify-between items-center pt-4 border-t">
                  <button
                    onClick={clearCart}
                    className="text-red-500 hover:text-red-700"
                  >
                    Clear Cart
                  </button>
                  <Link
                    to="/shop"
                    className="text-loom-green hover:text-green-600"
                  >
                    Continue Shopping
                  </Link>
                </div>
              </div>
            </div>

            {/* Order Summary */}
            <div>
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>{shipping === 0 ? 'Free' : `₹${shipping}`}</span>
                  </div>
                  <div className="border-t pt-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total</span>
                      <span>₹{total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
                {shipping > 0 && (
                  <p className="text-sm text-gray-600 mb-4">
                    Add ₹{(5000 - subtotal).toFixed(2)} more for free shipping
                  </p>
                )}
              </div>

              {/* Shipping Information */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-4">Shipping Information</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      name="fullName"
                      value={shippingInfo.fullName}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-loom-green"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <textarea
                      name="address"
                      value={shippingInfo.address}
                      onChange={handleInputChange}
                      rows="3"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-loom-green"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        City
                      </label>
                      <input
                        type="text"
                        name="city"
                        value={shippingInfo.city}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-loom-green"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        State
                      </label>
                      <input
                        type="text"
                        name="state"
                        value={shippingInfo.state}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-loom-green"
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Pincode
                      </label>
                      <input
                        type="text"
                        name="pincode"
                        value={shippingInfo.pincode}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-loom-green"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Phone
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={shippingInfo.phone}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-loom-green"
                        required
                      />
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleCheckout}
                  disabled={checkoutLoading}
                  className="w-full bg-loom-green text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-600 disabled:opacity-50 transition-colors mt-6"
                >
                  {checkoutLoading ? 'Processing...' : 'Proceed to Payment'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
      <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    </div>
  );
};

export default Cart;
