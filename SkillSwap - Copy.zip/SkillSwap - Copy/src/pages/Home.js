import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { api } from '../utils/api';

const Home = () => {
  const [products, setProducts] = useState([]);
  const [blogPosts, setBlogPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [productsResponse, blogResponse] = await Promise.all([
        api.get('/products'),
        api.get('/blog')
      ]);
      
      setProducts(productsResponse.data.slice(0, 8)); // Show first 8 products
      setBlogPosts(blogResponse.data.slice(0, 3)); // Show first 3 blog posts
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-loom-green"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-loom-dark to-gray-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              India's No. 1 Solar Company
            </h1>
            <p className="text-xl md:text-2xl mb-8">
              High-quality solar panels, batteries, and inverters for your home and business
            </p>
            <div className="flex justify-center space-x-4">
              <Link
                to="/shop"
                className="bg-loom-green text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors"
              >
                Shop Now
              </Link>
              <Link
                to="/contact"
                className="border-2 border-loom-green text-loom-green px-8 py-3 rounded-lg font-semibold hover:bg-loom-green hover:text-white transition-colors"
              >
                Get Quote
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-loom-green rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-clipboard-check text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Site Survey</h3>
              <p className="text-gray-600">
                We send our Engineers to your home for Site Survey! Book{' '}
                <span className="text-loom-green">Engineer Visit</span> to make your solar journey simple.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-loom-green rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-rupee-sign text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Finance- Solar on EMI</h3>
              <p className="text-gray-600">
                We have partnered with leading NBFCs, Private and Govt. banks to provide
                Solar on <span className="text-loom-green">Monthly EMI</span> equivalent to Electricity bill.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-loom-green rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-users text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Superior Customer Service</h3>
              <p className="text-gray-600">
                We generally give Instant <span className="text-loom-green">Digital Service</span> through
                Video calls and complaint Resolution within 3-7 days across India.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Product Range Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Product Range</h2>
            <Link to="/shop" className="text-loom-green hover:underline">
              View all →
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                <img
                  src="https://pixabay.com/get/g9bac11e5fd19aaf9ac187e68a842b8c8fde6aeafe4bc1ca2ed0a6e4d2329ee42ab6977c604375bd8b25a2368992405c8be12cfbd896a1b41237dc365e9ff8c0a_1280.jpg"
                  alt="Solar Panel"
                  className="w-16 h-16 object-cover rounded-full"
                />
              </div>
              <h3 className="text-lg font-semibold">Solar Panel</h3>
            </div>
            
            <div className="text-center">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                <img
                  src="https://pixabay.com/get/gf5247b58c8602ee848a54dd16715f6f6d7b9dc34dd660eae514c8abc3a21c8f8a5000892acda872977648e4ff7e1d5c75d9e08d56118e54415ce0ebeeed45df0_1280.jpg"
                  alt="Storage Battery"
                  className="w-16 h-16 object-cover rounded-full"
                />
              </div>
              <h3 className="text-lg font-semibold">Storage Battery</h3>
            </div>
            
            <div className="text-center">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                <img
                  src="https://pixabay.com/get/gf13029b28c9b68fd6d01405d9d1014c56456c0f43956e9dd863852332f4374d08efe1b04e87d8d05cb642937b6d7d924ba83fdf29caba6e419c19cce7bc8235c_1280.jpg"
                  alt="PV Inverter"
                  className="w-16 h-16 object-cover rounded-full"
                />
              </div>
              <h3 className="text-lg font-semibold">PV Inverter</h3>
            </div>
          </div>

          {/* Featured Products */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Solution Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://pixabay.com/get/gd0d523a848682cf2d87d854d5c6608edca4adc7ce6554680c4b72dcbb6bdfc633e8243af74efa9cee99ba82ec6d9c67c97c8cde9f5ed41bdb165968addde8a36_1280.jpg"
                alt="Residential"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Residential</h3>
                  <p className="mb-4">Up to 10kW rooftop solar is available for homes</p>
                  <Link
                    to="/shop"
                    className="bg-loom-green text-white px-6 py-2 rounded-lg hover:bg-green-600 transition-colors"
                  >
                    Learn more
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://pixabay.com/get/g1b6572e65c3489ad6edab6a315bad65a31becdf8582687f2f77d8e995d0dc1ac926d23ed8485c89ef12bc3932eaa4b8c9d1d8c9aaaa131f1ef04d6ec5ef0afff_1280.jpg"
                alt="Commercial"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Commercial & Industrial</h3>
                  <p className="mb-4">We provide solar solutions up to 1MW for MSMEs</p>
                  <Link
                    to="/shop"
                    className="bg-loom-green text-white px-6 py-2 rounded-lg hover:bg-green-600 transition-colors"
                  >
                    Learn more
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img
                src="https://pixabay.com/get/g481816635d92ba716b286acc085260b374a9c9c4beabd0e460b83ec191600a869a0e9c2a6aa04df3298fd27f0abe505623de8f0aef63f6198b0434ed68779be3_1280.jpg"
                alt="Agriculture"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Agriculture</h3>
                  <p className="mb-4">During the day, our solar solution can reduce diesel consumption</p>
                  <Link
                    to="/shop"
                    className="bg-loom-green text-white px-6 py-2 rounded-lg hover:bg-green-600 transition-colors"
                  >
                    Learn more
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">About Us</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Loom Solar is a leading manufacturer of Solar Power Generating Systems / Parts, founded in 2018 by
              two brothers Amod and Amol Anand. With continuous research and development effort of our team of
              150+ highly skilled individuals, and 2 manufacturing units, we manufacture the cutting edge solar
              products including solar panel, battery and inverter in India and sell them globally to more than 10
              countries through a vast network of 10,000+ dealers and have over 50,000 satisfied customers.
            </p>
            <div className="mt-8">
              <button className="bg-loom-green text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors">
                Discover Our Brand
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Latest from our blogs</h2>
            <Link to="/blog" className="text-loom-green hover:underline">
              View all →
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {blogPosts.map(post => (
              <div key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src={post.image_url}
                  alt={post.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="text-sm text-loom-green mb-2">LOOM SOLAR</div>
                  <h3 className="text-lg font-semibold mb-2">
                    <Link to={`/blog/${post.id}`} className="hover:text-loom-green">
                      {post.title}
                    </Link>
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <span>{post.first_name} {post.last_name}</span>
                    <span>{new Date(post.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
