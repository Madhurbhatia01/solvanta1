import { api } from './api';

class AuthService {
  constructor() {
    this.token = localStorage.getItem('token');
    this.user = JSON.parse(localStorage.getItem('user') || 'null');
  }

  async login(email, password) {
    try {
      const response = await api.post('/auth/login', { email, password });
      const { token, user } = response.data;
      
      this.setSession(token, user);
      return { token, user };
    } catch (error) {
      throw new Error(error.response?.data?.error || 'Login failed');
    }
  }

  async register(email, password, firstName, lastName) {
    try {
      const response = await api.post('/auth/register', {
        email,
        password,
        firstName,
        lastName
      });
      const { token, user } = response.data;
      
      this.setSession(token, user);
      return { token, user };
    } catch (error) {
      throw new Error(error.response?.data?.error || 'Registration failed');
    }
  }

  async getCurrentUser() {
    try {
      if (!this.token) return null;
      
      const response = await api.get('/auth/user');
      return response.data.user;
    } catch (error) {
      this.logout();
      return null;
    }
  }

  setSession(token, user) {
    this.token = token;
    this.user = user;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
  }

  logout() {
    this.token = null;
    this.user = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
  }

  isAuthenticated() {
    return !!this.token;
  }

  getToken() {
    return this.token;
  }

  getUser() {
    return this.user;
  }

  isAdmin() {
    return this.user?.role === 'admin';
  }

  // Validate token format
  isValidToken(token) {
    if (!token) return false;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  }

  // Check if user has specific permissions
  hasPermission(permission) {
    if (!this.user) return false;
    if (this.user.role === 'admin') return true;
    return this.user.permissions?.includes(permission) || false;
  }
}

export const authService = new AuthService();

// Helper functions for components
export const isAuthenticated = () => authService.isAuthenticated();
export const getCurrentUser = () => authService.getUser();
export const isAdmin = () => authService.isAdmin();
export const logout = () => authService.logout();
