/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html",
  ],
  theme: {
    extend: {
      colors: {
        'loom-green': '#22C55E',
        'loom-dark': '#1F2937',
        'loom-light': '#F9FAFB',
        'loom-gray': {
          50: '#F9FAFB',
          100: '#F3F4F6',
          200: '#E5E7EB',
          300: '#D1D5DB',
          400: '#9CA3AF',
          500: '#6B7280',
          600: '#4B5563',
          700: '#374151',
          800: '#1F2937',
          900: '#111827',
        },
        'loom-green-variants': {
          50: '#F0FDF4',
          100: '#DCFCE7',
          200: '#BBF7D0',
          300: '#86EFAC',
          400: '#4ADE80',
          500: '#22C55E',
          600: '#16A34A',
          700: '#15803D',
          800: '#166534',
          900: '#14532D',
        }
      },
      fontFamily: {
        'sans': ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', 'sans-serif'],
        'mono': ['source-code-pro', 'Menlo', 'Monaco', 'Consolas', 'Courier New', 'monospace'],
      },
      spacing: {
        '72': '18rem',
        '84': '21rem',
        '96': '24rem',
        '128': '32rem',
      },
      maxWidth: {
        '8xl': '88rem',
        '9xl': '96rem',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-out',
        'slide-in': 'slideIn 0.3s ease-out',
        'bounce-slow': 'bounce 2s infinite',
        'pulse-slow': 'pulse 3s infinite',
        'spin-slow': 'spin 3s linear infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideIn: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(0)' },
        },
      },
      boxShadow: {
        'loom': '0 4px 14px 0 rgba(34, 197, 94, 0.39)',
        'loom-lg': '0 10px 25px 0 rgba(34, 197, 94, 0.25)',
        'inner-light': 'inset 0 2px 4px 0 rgba(255, 255, 255, 0.06)',
      },
      backgroundImage: {
        'gradient-loom': 'linear-gradient(135deg, #22C55E 0%, #16A34A 100%)',
        'gradient-dark': 'linear-gradient(135deg, #1F2937 0%, #111827 100%)',
        'gradient-light': 'linear-gradient(135deg, #F9FAFB 0%, #F3F4F6 100%)',
        'solar-pattern': "url('data:image/svg+xml,<svg width=\"60\" height=\"60\" viewBox=\"0 0 60 60\" xmlns=\"http://www.w3.org/2000/svg\"><g fill=\"none\" fill-rule=\"evenodd\"><g fill=\"%2322C55E\" fill-opacity=\"0.05\"><polygon points=\"30 0 60 30 30 60 0 30\"/></g></g></svg>')",
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
        '3xl': '2rem',
      },
      fontSize: {
        'xs': ['0.75rem', { lineHeight: '1rem' }],
        'sm': ['0.875rem', { lineHeight: '1.25rem' }],
        'base': ['1rem', { lineHeight: '1.5rem' }],
        'lg': ['1.125rem', { lineHeight: '1.75rem' }],
        'xl': ['1.25rem', { lineHeight: '1.75rem' }],
        '2xl': ['1.5rem', { lineHeight: '2rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        '5xl': ['3rem', { lineHeight: '1' }],
        '6xl': ['3.75rem', { lineHeight: '1' }],
        '7xl': ['4.5rem', { lineHeight: '1' }],
        '8xl': ['6rem', { lineHeight: '1' }],
        '9xl': ['8rem', { lineHeight: '1' }],
      },
      screens: {
        'xs': '475px',
        'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
        '2xl': '1536px',
        '3xl': '1920px',
      },
      zIndex: {
        '60': '60',
        '70': '70',
        '80': '80',
        '90': '90',
        '100': '100',
      },
      aspectRatio: {
        '4/3': '4 / 3',
        '3/2': '3 / 2',
        '2/3': '2 / 3',
        '9/16': '9 / 16',
      },
      backdropBlur: {
        xs: '2px',
      },
      transitionProperty: {
        'height': 'height',
        'spacing': 'margin, padding',
      },
      transitionDuration: {
        '0': '0ms',
        '2000': '2000ms',
        '3000': '3000ms',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms')({
      strategy: 'class',
    }),
    require('@tailwindcss/typography'),
    require('@tailwindcss/aspect-ratio'),
    // Custom plugin for Loom Solar specific utilities
    function({ addUtilities, addComponents, theme }) {
      const newUtilities = {
        '.text-balance': {
          'text-wrap': 'balance',
        },
        '.bg-solar-pattern': {
          'background-image': `url("data:image/svg+xml,<svg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'><g fill='none' fill-rule='evenodd'><g fill='${theme('colors.loom-green.DEFAULT')}' fill-opacity='0.05'><polygon points='30 0 60 30 30 60 0 30'/></g></g></svg>")`,
        },
        '.glass': {
          'backdrop-filter': 'blur(16px) saturate(180%)',
          'background-color': 'rgba(255, 255, 255, 0.75)',
          'border': '1px solid rgba(209, 213, 219, 0.3)',
        },
        '.glass-dark': {
          'backdrop-filter': 'blur(16px) saturate(180%)',
          'background-color': 'rgba(31, 41, 55, 0.75)',
          'border': '1px solid rgba(75, 85, 99, 0.3)',
        },
      }
      
      const newComponents = {
        '.btn-loom': {
          'padding': '0.75rem 1.5rem',
          'background-color': theme('colors.loom-green.DEFAULT'),
          'color': 'white',
          'border-radius': '0.5rem',
          'font-weight': '600',
          'transition': 'all 0.3s ease',
          '&:hover': {
            'background-color': theme('colors.loom-green.600'),
            'transform': 'translateY(-2px)',
            'box-shadow': theme('boxShadow.loom'),
          },
          '&:active': {
            'transform': 'translateY(0)',
          },
          '&:disabled': {
            'opacity': '0.5',
            'cursor': 'not-allowed',
            'transform': 'none',
          },
        },
        '.btn-loom-outline': {
          'padding': '0.75rem 1.5rem',
          'background-color': 'transparent',
          'color': theme('colors.loom-green.DEFAULT'),
          'border': `2px solid ${theme('colors.loom-green.DEFAULT')}`,
          'border-radius': '0.5rem',
          'font-weight': '600',
          'transition': 'all 0.3s ease',
          '&:hover': {
            'background-color': theme('colors.loom-green.DEFAULT'),
            'color': 'white',
            'transform': 'translateY(-2px)',
          },
        },
        '.card-loom': {
          'background-color': 'white',
          'border-radius': '0.75rem',
          'box-shadow': theme('boxShadow.md'),
          'padding': '1.5rem',
          'transition': 'all 0.3s ease',
          '&:hover': {
            'transform': 'translateY(-4px)',
            'box-shadow': theme('boxShadow.xl'),
          },
        },
        '.input-loom': {
          'width': '100%',
          'padding': '0.75rem 1rem',
          'border': `1px solid ${theme('colors.gray.300')}`,
          'border-radius': '0.5rem',
          'background-color': 'white',
          'transition': 'border-color 0.2s, box-shadow 0.2s',
          '&:focus': {
            'outline': 'none',
            'border-color': theme('colors.loom-green.DEFAULT'),
            'box-shadow': `0 0 0 3px ${theme('colors.loom-green.DEFAULT')}33`,
          },
        },
      }
      
      addUtilities(newUtilities)
      addComponents(newComponents)
    },
  ],
  darkMode: 'class',
  future: {
    hoverOnlyWhenSupported: true,
  },
}
